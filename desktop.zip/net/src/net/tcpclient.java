package net;



import java.io.*;
import java.net.*;

class TCPClient {

	public static void main(String argv[]) throws Exception {
		String sentence;
		String modifiedSentene;
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		sentence = inFromUser.readLine();
		if (sentence.equals("CONNECT")) {
			System.out.println("connected");
			BufferedReader inFromUser2 = null ;
			while (true) {
				sentence = inFromUser2.readLine();
				Socket clientSocket = new Socket("127.0.0.1", 6666);
				 inFromUser2 = new BufferedReader(new InputStreamReader(System.in));
				BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
				DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
				
				
				if(!sentence.equals("END")) {
					outToServer.writeBytes(sentence + '\n');
					outToServer.flush();
					modifiedSentene=inFromServer.readLine();
					System.out.println("server:" + sentence);
				}
				
				else  {
					clientSocket.close();
					return;
				}

			}
		}

	}
}